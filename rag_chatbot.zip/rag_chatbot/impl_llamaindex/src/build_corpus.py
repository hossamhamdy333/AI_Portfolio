"""Build the 4-domain corpus from Wikipedia via HuggingFace `datasets`.

Run this in Colab, same pattern as impl_vanilla's XLSum pipeline: pull a real
dump, filter it down with actual logic (not hand-picked pages), validate,
save one clean parquet per domain to data/processed/<domain>/.

Uses the community-maintained `wikimedia/wikipedia` dataset (20231101.en
snapshot) -- properly licensed (CC BY-SA), built for exactly this kind of
downstream ML use, and lets us filter by real category signal instead of
guessing article titles by hand.
"""

from datasets import load_dataset
import pandas as pd

# Keyword sets used to match articles into a domain via title/category text.
# Deliberately conservative (specific terms) to keep precision high -- a
# false-positive "sports" article showing up in "tech" would quietly hurt
# the router's routing-accuracy metric later.
DOMAIN_KEYWORDS = {
    "sports": [
        "football", "cricket", "basketball", "tennis", "olympic", "athlete",
        "championship", "tournament", "fifa", "nba", "rugby", "baseball",
    ],
    "tech": [
        "computer", "software", "internet", "artificial intelligence",
        "programming", "semiconductor", "smartphone", "cybersecurity",
        "cloud computing", "database", "algorithm",
    ],
    "history": [
        "war", "empire", "revolution", "dynasty", "ancient", "medieval",
        "kingdom", "civilization", "battle of", "treaty of",
    ],
    "english_literature": [
        "novel", "poet", "poetry", "playwright", "shakespeare", "literary",
        "fiction", "author", "victorian literature", "romantic poetry",
    ],
}

TARGET_PER_DOMAIN = 300  # matches the scale-down ratio vanilla used (37.5K -> 300 eval)


def article_matches_domain(title, text, keywords):
    haystack = (title + " " + text[:500]).lower()
    return any(kw in haystack for kw in keywords)


def build_domain_corpus(dataset_split, domain_keywords, target_per_domain, seed=42):
    """Stream the wikipedia dump once, bucket matching articles per domain.

    Streaming (not loading the full ~20GB dump into memory) since we only
    need a few hundred articles per domain out of millions.
    """
    buckets = {domain: [] for domain in domain_keywords}
    filled = set()

    for row in dataset_split:
        if len(filled) == len(domain_keywords):
            break
        title, text = row["title"], row["text"]
        for domain, keywords in domain_keywords.items():
            if domain in filled:
                continue
            if article_matches_domain(title, text, keywords):
                buckets[domain].append({"title": title, "text": text, "domain": domain})
                if len(buckets[domain]) >= target_per_domain:
                    filled.add(domain)
                break  # one domain per article, avoid double-counting

    return buckets


def save_domain_parquets(buckets, output_dir):
    for domain, rows in buckets.items():
        df = pd.DataFrame(rows)
        df["article_id"] = [f"{domain}_{i}" for i in range(len(df))]
        out_path = f"{output_dir}/{domain}.parquet"
        df.to_parquet(out_path, index=False)
        print(f"{domain}: {len(df)} articles -> {out_path}")


if __name__ == "__main__":
    wiki = load_dataset("wikimedia/wikipedia", "20231101.en", split="train", streaming=True)
    buckets = build_domain_corpus(wiki, DOMAIN_KEYWORDS, TARGET_PER_DOMAIN)
    save_domain_parquets(buckets, output_dir="data/processed")
